/*******************************************************************************
* File Name: SDCard_SD_PWR.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SDCard_SD_PWR_H) /* Pins SDCard_SD_PWR_H */
#define CY_PINS_SDCard_SD_PWR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SDCard_SD_PWR_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SDCard_SD_PWR_Write(uint8 value) ;
void    SDCard_SD_PWR_SetDriveMode(uint8 mode) ;
uint8   SDCard_SD_PWR_ReadDataReg(void) ;
uint8   SDCard_SD_PWR_Read(void) ;
uint8   SDCard_SD_PWR_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SDCard_SD_PWR_DRIVE_MODE_BITS        (3)
#define SDCard_SD_PWR_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SDCard_SD_PWR_DRIVE_MODE_BITS))
#define SDCard_SD_PWR_DRIVE_MODE_SHIFT       (0x00u)
#define SDCard_SD_PWR_DRIVE_MODE_MASK        (0x07u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)

#define SDCard_SD_PWR_DM_ALG_HIZ         (0x00u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_DIG_HIZ         (0x01u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_RES_UP          (0x02u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_RES_DWN         (0x03u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_OD_LO           (0x04u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_OD_HI           (0x05u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_STRONG          (0x06u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)
#define SDCard_SD_PWR_DM_RES_UPDWN       (0x07u << SDCard_SD_PWR_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define SDCard_SD_PWR_MASK               SDCard_SD_PWR__MASK
#define SDCard_SD_PWR_SHIFT              SDCard_SD_PWR__SHIFT
#define SDCard_SD_PWR_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SDCard_SD_PWR_PS                     (* (reg32 *) SDCard_SD_PWR__PS)
/* Port Configuration */
#define SDCard_SD_PWR_PC                     (* (reg32 *) SDCard_SD_PWR__PC)
/* Data Register */
#define SDCard_SD_PWR_DR                     (* (reg32 *) SDCard_SD_PWR__DR)
/* Input Buffer Disable Override */
#define SDCard_SD_PWR_INP_DIS                (* (reg32 *) SDCard_SD_PWR__PC2)


#if defined(SDCard_SD_PWR__INTSTAT)  /* Interrupt Registers */

    #define SDCard_SD_PWR_INTSTAT                (* (reg32 *) SDCard_SD_PWR__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins SDCard_SD_PWR_H */


/* [] END OF FILE */
