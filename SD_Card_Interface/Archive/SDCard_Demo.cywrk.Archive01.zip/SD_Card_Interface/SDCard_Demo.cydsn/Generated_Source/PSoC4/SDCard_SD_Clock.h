/*******************************************************************************
* File Name: SDCard_SD_Clock.h
* Version 2.0
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_SDCard_SD_Clock_H)
#define CY_CLOCK_SDCard_SD_Clock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/

void SDCard_SD_Clock_Start(void);
void SDCard_SD_Clock_Stop(void);

void SDCard_SD_Clock_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 SDCard_SD_Clock_GetDividerRegister(void);
uint8  SDCard_SD_Clock_GetFractionalDividerRegister(void);

#define SDCard_SD_Clock_Enable()                         SDCard_SD_Clock_Start()
#define SDCard_SD_Clock_Disable()                        SDCard_SD_Clock_Stop()
#define SDCard_SD_Clock_SetDividerRegister(clkDivider, reset)  \
                        SDCard_SD_Clock_SetFractionalDividerRegister((clkDivider), 0)
#define SDCard_SD_Clock_SetDivider(clkDivider)           SDCard_SD_Clock_SetDividerRegister((clkDivider), 1)
#define SDCard_SD_Clock_SetDividerValue(clkDivider)      SDCard_SD_Clock_SetDividerRegister((clkDivider) - 1, 1)


/***************************************
*             Registers
***************************************/

#define SDCard_SD_Clock_DIV_REG    (*(reg32 *)SDCard_SD_Clock__REGISTER)
#define SDCard_SD_Clock_ENABLE_REG SDCard_SD_Clock_DIV_REG

#endif /* !defined(CY_CLOCK_SDCard_SD_Clock_H) */

/* [] END OF FILE */
