/*******************************************************************************
* File Name: SDCard_SPIM_mosi_m.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SDCard_SPIM_mosi_m_H) /* Pins SDCard_SPIM_mosi_m_H */
#define CY_PINS_SDCard_SPIM_mosi_m_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SDCard_SPIM_mosi_m_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SDCard_SPIM_mosi_m_Write(uint8 value) ;
void    SDCard_SPIM_mosi_m_SetDriveMode(uint8 mode) ;
uint8   SDCard_SPIM_mosi_m_ReadDataReg(void) ;
uint8   SDCard_SPIM_mosi_m_Read(void) ;
uint8   SDCard_SPIM_mosi_m_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SDCard_SPIM_mosi_m_DRIVE_MODE_BITS        (3)
#define SDCard_SPIM_mosi_m_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SDCard_SPIM_mosi_m_DRIVE_MODE_BITS))
#define SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT       (0x00u)
#define SDCard_SPIM_mosi_m_DRIVE_MODE_MASK        (0x07u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)

#define SDCard_SPIM_mosi_m_DM_ALG_HIZ         (0x00u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_DIG_HIZ         (0x01u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_RES_UP          (0x02u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_RES_DWN         (0x03u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_OD_LO           (0x04u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_OD_HI           (0x05u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_STRONG          (0x06u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)
#define SDCard_SPIM_mosi_m_DM_RES_UPDWN       (0x07u << SDCard_SPIM_mosi_m_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define SDCard_SPIM_mosi_m_MASK               SDCard_SPIM_mosi_m__MASK
#define SDCard_SPIM_mosi_m_SHIFT              SDCard_SPIM_mosi_m__SHIFT
#define SDCard_SPIM_mosi_m_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SDCard_SPIM_mosi_m_PS                     (* (reg32 *) SDCard_SPIM_mosi_m__PS)
/* Port Configuration */
#define SDCard_SPIM_mosi_m_PC                     (* (reg32 *) SDCard_SPIM_mosi_m__PC)
/* Data Register */
#define SDCard_SPIM_mosi_m_DR                     (* (reg32 *) SDCard_SPIM_mosi_m__DR)
/* Input Buffer Disable Override */
#define SDCard_SPIM_mosi_m_INP_DIS                (* (reg32 *) SDCard_SPIM_mosi_m__PC2)


#if defined(SDCard_SPIM_mosi_m__INTSTAT)  /* Interrupt Registers */

    #define SDCard_SPIM_mosi_m_INTSTAT                (* (reg32 *) SDCard_SPIM_mosi_m__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins SDCard_SPIM_mosi_m_H */


/* [] END OF FILE */
