/*******************************************************************************
* File Name: SDCard_SPIM_BOOT.c
* Version 1.0
*
* Description:
*  This file provides the source code to the API for the bootloader
*  communication support in SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SDCard_SPIM.h"

#if(SDCard_SPIM_SCB_MODE_I2C_INC)
    #include "SDCard_SPIM_I2C.h"
#endif /* (SDCard_SPIM_SCB_MODE_I2C_INC) */

#if(SDCard_SPIM_SCB_MODE_SPI_INC || SDCard_SPIM_SCB_MODE_UART_INC)
    #include "SDCard_SPIM_SPI_UART.h"
#endif /* (SDCard_SPIM_SCB_MODE_SPI_INC || SDCard_SPIM_SCB_MODE_UART_INC) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SDCard_SPIM) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

/*******************************************************************************
* Function Name: SDCard_SPIM_CyBtldrCommStart
********************************************************************************
*
* Summary:
*  Calls Start function fucntion of the bootloader communication component for
*  selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SDCard_SPIM_CyBtldrCommStart(void)
{
    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            SDCard_SPIM_I2CCyBtldrCommStart();
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            SDCard_SPIM_SpiCyBtldrCommStart();
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            SDCard_SPIM_UartCyBtldrCommStart();
        }
        else
        {
            /* Unknown mode: do nothing */
        }
    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        SDCard_SPIM_I2CCyBtldrCommStart();

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        SDCard_SPIM_SpiCyBtldrCommStart();

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        SDCard_SPIM_UartCyBtldrCommStart();

    #else
        /* Do nothing */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SDCard_SPIM_CyBtldrCommStop
********************************************************************************
*
* Summary:
*  Calls Stop function fucntion of the bootloader communication component for
*  selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SDCard_SPIM_CyBtldrCommStop(void)
{
    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            SDCard_SPIM_I2CCyBtldrCommStop();
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            SDCard_SPIM_SpiCyBtldrCommStop();
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            SDCard_SPIM_UartCyBtldrCommStop();
        }
        else
        {
            /* Unknown mode: do nothing */
        }
    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        SDCard_SPIM_I2CCyBtldrCommStop();

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        SDCard_SPIM_SpiCyBtldrCommStop();

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        SDCard_SPIM_UartCyBtldrCommStop();

    #else
        /* Do nothing */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SDCard_SPIM_CyBtldrCommReset
********************************************************************************
*
* Summary:
*  Calls reset function fucntion of the bootloader communication component for
*  selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SDCard_SPIM_CyBtldrCommReset(void)
{
    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            SDCard_SPIM_I2CCyBtldrCommReset();
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            SDCard_SPIM_SpiCyBtldrCommReset();
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            SDCard_SPIM_UartCyBtldrCommReset();
        }
        else
        {
            /* Unknown mode: do nothing */
        }
    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        SDCard_SPIM_I2CCyBtldrCommReset();

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        SDCard_SPIM_SpiCyBtldrCommReset();

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        SDCard_SPIM_UartCyBtldrCommReset();

    #else
        /* Do nothing */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SDCard_SPIM_CyBtldrCommRead
********************************************************************************
*
* Summary:
*  Calls read fucntion of the bootloader communication component for selected
*  mode.
*
* Parameters:
*  pData:    Pointer to storage for the block of data to be read from the
*            bootloader host
*  size:     Number of bytes to be read.
*  count:    Pointer to the variable to write the number of bytes actually
*            read.
*  timeOut:  Number of units in 10 ms to wait before returning because of a
*            timeout.
*
* Return:
*  Returns CYRET_SUCCESS if no problem was encountered or returns the value
*  that best describes the problem.
*
*******************************************************************************/
cystatus SDCard_SPIM_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut)
{
    cystatus status;

    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            status = SDCard_SPIM_I2CCyBtldrCommRead(pData, size, count, timeOut);
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            status = SDCard_SPIM_SpiCyBtldrCommRead(pData, size, count, timeOut);
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            status = SDCard_SPIM_UartCyBtldrCommRead(pData, size, count, timeOut);
        }
        else
        {
            status = CYRET_INVALID_STATE; /* Unknown mode: return status */
        }

    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        status = SDCard_SPIM_I2CCyBtldrCommRead(pData, size, count, timeOut);

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        status = SDCard_SPIM_SpiCyBtldrCommRead(pData, size, count, timeOut);

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        status = SDCard_SPIM_UartCyBtldrCommRead(pData, size, count, timeOut);

    #else
        status = CYRET_INVALID_STATE; /* Unknown mode: return status */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */

    return(status);
}


/*******************************************************************************
* Function Name: SDCard_SPIM_CyBtldrCommWrite
********************************************************************************
*
* Summary:
*  Calls write fucntion of the bootloader communication component for selected
*  mode.
*
* Parameters:
*  pData:    Pointer to the block of data to be written to the bootloader host.
*  size:     Number of bytes to be written.
*  count:    Pointer to the variable to write the number of bytes actually
*            written.
*  timeOut:  Number of units in 10 ms to wait before returning because of a
*            timeout.
*
* Return:
*  Returns CYRET_SUCCESS if no problem was encountered or returns the value
*  that best describes the problem.
*
*******************************************************************************/
cystatus SDCard_SPIM_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut)
{
    cystatus status;

    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            status = SDCard_SPIM_I2CCyBtldrCommWrite(pData, size, count, timeOut);
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            status = SDCard_SPIM_SpiCyBtldrCommWrite(pData, size, count, timeOut);
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            status = SDCard_SPIM_UartCyBtldrCommWrite(pData, size, count, timeOut);
        }
        else
        {
            status = CYRET_INVALID_STATE; /* Unknown mode: return status */
        }
    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        status = SDCard_SPIM_I2CCyBtldrCommWrite(pData, size, count, timeOut);

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        status = SDCard_SPIM_SpiCyBtldrCommWrite(pData, size, count, timeOut);

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        status = SDCard_SPIM_UartCyBtldrCommWrite(pData, size, count, timeOut);

    #else
        status = CYRET_INVALID_STATE; /* Unknown mode: return status */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */

    return(status);
}

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SDCard_SPIM) || \
                                                    (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface)) */


/* [] END OF FILE */
