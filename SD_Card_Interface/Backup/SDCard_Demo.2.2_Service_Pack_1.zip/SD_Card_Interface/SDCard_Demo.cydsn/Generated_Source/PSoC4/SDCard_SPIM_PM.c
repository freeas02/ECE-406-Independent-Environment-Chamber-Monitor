/*******************************************************************************
* File Name: SDCard_SPIM_PM.c
* Version 1.0
*
* Description:
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SDCard_SPIM.h"

#if(SDCard_SPIM_SCB_MODE_I2C_INC)
    #include "SDCard_SPIM_I2C_PVT.h"
#endif /* (SDCard_SPIM_SCB_MODE_I2C_INC) */

#if(SDCard_SPIM_SCB_MODE_SPI_INC || SDCard_SPIM_SCB_MODE_UART_INC)
    #include "SDCard_SPIM_SPI_UART_PVT.h"
#endif /* (SDCard_SPIM_SCB_MODE_SPI_INC || SDCard_SPIM_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

SDCard_SPIM_BACKUP_STRUCT SDCard_SPIM_backup =
{
    0u, /* enableState */
};


/*******************************************************************************
* Function Name: SDCard_SPIM_Sleep
********************************************************************************
*
* Summary:
*  Calls SaveConfig function fucntion for selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SDCard_SPIM_Sleep(void)
{
    SDCard_SPIM_backup.enableState = (uint8) SDCard_SPIM_GET_CTRL_ENABLED;

    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            SDCard_SPIM_I2CSaveConfig();
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            SDCard_SPIM_SpiSaveConfig();
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            SDCard_SPIM_UartSaveConfig();
        }
        else
        {
            /* Unknown mode: do nothing */
        }

    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        SDCard_SPIM_I2CSaveConfig();

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        SDCard_SPIM_SpiSaveConfig();

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        SDCard_SPIM_UartSaveConfig();

    #else
        /* Do nothing */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */

    if(0u != SDCard_SPIM_backup.enableState)
    {
        SDCard_SPIM_Stop();
    }
}


/*******************************************************************************
* Function Name: SDCard_SPIM_Wakeup
********************************************************************************
*
* Summary:
*  Calls RestoreConfig function fucntion for selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SDCard_SPIM_Wakeup(void)
{
    #if(SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

        if(SDCard_SPIM_SCB_MODE_I2C_RUNTM_CFG)
        {
            SDCard_SPIM_I2CRestoreConfig();
        }
        else if(SDCard_SPIM_SCB_MODE_SPI_RUNTM_CFG)
        {
            SDCard_SPIM_SpiRestoreConfig();
        }
        else if(SDCard_SPIM_SCB_MODE_UART_RUNTM_CFG)
        {
            SDCard_SPIM_UartRestoreConfig();
        }
        else
        {
            /* Unknown mode: do nothing */
        }

    #elif(SDCard_SPIM_SCB_MODE_I2C_CONST_CFG)
        SDCard_SPIM_I2CRestoreConfig();

    #elif(SDCard_SPIM_SCB_MODE_SPI_CONST_CFG)
        SDCard_SPIM_SpiRestoreConfig();

    #elif(SDCard_SPIM_SCB_MODE_UART_CONST_CFG)
        SDCard_SPIM_UartRestoreConfig();

    #else
        /* Do nothing */

    #endif /* (SDCard_SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */

    if(0u != SDCard_SPIM_backup.enableState)
    {
        SDCard_SPIM_Enable();
    }
}


/* [] END OF FILE */
