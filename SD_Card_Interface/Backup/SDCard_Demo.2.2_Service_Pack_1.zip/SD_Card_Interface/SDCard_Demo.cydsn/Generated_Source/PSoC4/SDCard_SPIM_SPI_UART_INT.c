/*******************************************************************************
* File Name: SDCard_SPIM_SPI_UART_INT.c
* Version 1.0
*
* Description:
*  This file provides the source code to the Interrupt Servive Routine for
*  the SCB Component in SPI and UART modes.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SDCard_SPIM_PVT.h"
#include "SDCard_SPIM_SPI_UART_PVT.h"


/*******************************************************************************
* Function Name: SDCard_SPIM_SPI_UART_ISR
********************************************************************************
*
* Summary:
*  Handles Interrupt Service Routine for SCB SPI or UART modes.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(SDCard_SPIM_SPI_UART_ISR)
{
    #if(SDCard_SPIM_INTERNAL_RX_SW_BUFFER_CONST)
        uint32 locHead;
        uint32 dataRx;
    #endif /* (SDCard_SPIM_INTERNAL_RX_SW_BUFFER_CONST) */

    #if(SDCard_SPIM_INTERNAL_TX_SW_BUFFER_CONST)
        uint32 locTail;
    #endif /* (SDCard_SPIM_INTERNAL_TX_SW_BUFFER_CONST) */

    if(NULL != SDCard_SPIM_customIntrHandler)
    {
        SDCard_SPIM_customIntrHandler(); /* Call customer routine if needed */
    }

    #if(SDCard_SPIM_CHECK_SPI_WAKE_ENABLE)
    {
        /* Always clear SS activation */
        SDCard_SPIM_ClearSpiExtClkInterruptSource(SDCard_SPIM_INTR_SPI_EC_WAKE_UP);
    }
    #endif

    #if(SDCard_SPIM_CHECK_RX_SW_BUFFER)
    {
        /* Get data from RX FIFO */
        if(SDCard_SPIM_CHECK_INTR_RX_MASKED(SDCard_SPIM_INTR_RX_NOT_EMPTY))
        {
            while(0u != SDCard_SPIM_GET_RX_FIFO_ENTRIES)
            {
                /* Get data from RX FIFO */
                dataRx = SDCard_SPIM_RX_FIFO_RD_REG;

                /* Move local head index */
                locHead = (SDCard_SPIM_rxBufferHead + 1u);

                /* Adjust local head index */
                if(SDCard_SPIM_RX_BUFFER_SIZE == locHead)
                {
                    locHead = 0u;
                }

                if(locHead == SDCard_SPIM_rxBufferTail)
                {
                    /* Overflow: through away new data */
                    SDCard_SPIM_rxBufferOverflow = (uint8) SDCard_SPIM_INTR_RX_OVERFLOW;
                }
                else
                {
                    /* Store received data */
                    SDCard_SPIM_PutWordInRxBuffer(locHead, dataRx);

                    /* Move head index */
                    SDCard_SPIM_rxBufferHead = locHead;
                }
            }

            SDCard_SPIM_ClearRxInterruptSource(SDCard_SPIM_INTR_RX_NOT_EMPTY);
        }
    }
    #endif


    #if(SDCard_SPIM_CHECK_TX_SW_BUFFER)
    {
        if(SDCard_SPIM_CHECK_INTR_TX_MASKED(SDCard_SPIM_INTR_TX_EMPTY))
        {
            /* Put data into TX FIFO */
            while(SDCard_SPIM_FIFO_SIZE != SDCard_SPIM_GET_TX_FIFO_ENTRIES)
            {
                /* There is a data in TX software buffer */
                if(SDCard_SPIM_txBufferHead != SDCard_SPIM_txBufferTail)
                {
                    /* Mode local tail index */
                    locTail = (SDCard_SPIM_txBufferTail + 1u);

                    /* Adjust local tail index */
                    if(SDCard_SPIM_TX_BUFFER_SIZE == locTail)
                    {
                        locTail = 0u;
                    }

                    /* Put data into TX FIFO */
                    SDCard_SPIM_TX_FIFO_WR_REG = SDCard_SPIM_GetWordFromTxBuffer(locTail);

                    /* Mode tail index */
                    SDCard_SPIM_txBufferTail = locTail;
                }
                else
                {
                    /* TX software buffer is EMPTY: end of transmitting */
                    SDCard_SPIM_DISABLE_INTR_TX(SDCard_SPIM_INTR_TX_EMPTY);
                    break;
                }
            }

            SDCard_SPIM_ClearTxInterruptSource(SDCard_SPIM_INTR_TX_EMPTY);
        }
    }
    #endif
}


/* [] END OF FILE */
